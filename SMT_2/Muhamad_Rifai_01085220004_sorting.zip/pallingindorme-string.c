
// This code is made in regards of solving problem A on weak 2 Assignment:
// Name : Muhamad Rifai
// NIM : 01085220004
#include <stdio.h>
 int main(){
    
 }